package com.gogo.constant;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

/*
 * purpose of the class file
 * @params ab, string 
 */
public class Constants {
	
	public String InputTestData = System.getProperty("user.dir") + "/Excel/Input/"+"InputTestData.xlsx";
	public String chromeDriverExe = System.getProperty("user.dir") + "/Driver/"+"chromedriver.exe";
	public String fireFoxDriverExe = System.getProperty("user.dir") + "/Driver/"+"geckodriver.exe";

	
	
	
	
	
	
	
		
}

