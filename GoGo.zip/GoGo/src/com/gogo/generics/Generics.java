package com.gogo.generics;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.gogo.utilities.Log;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

/*
 * purpose of the class file
 * @params ab, string 
 */
public class Generics {

	public String propertyFile(String propValue) throws IOException {
		try {

			Properties prop = new Properties();
			String path = System.getProperty("user.dir")
					+ "/PropertyFile/App.properties";
			FileInputStream inputPath = new FileInputStream(path);
			prop.load(inputPath);
			String propVal = prop.getProperty(propValue);
			return propVal;
		} catch (Exception e) {
			Log.info("Property file name is not available as we expected");
			e.printStackTrace();
		}
		String propVal = null;
		System.out.println("Print the property value" + propVal);
		return propVal;
	}

	public void SelectOption(WebElement dropDownSel, String dropDownVal) {
		try {
			Select sel = new Select(dropDownSel);
			sel.selectByVisibleText(dropDownVal);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
