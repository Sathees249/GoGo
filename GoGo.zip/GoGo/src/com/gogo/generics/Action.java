package com.gogo.generics;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gogo.utilities.Log;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

public class Action {
	WebDriver driver;
	WebDriverWait wait;
	public static Dimension size;

	public Action(WebDriver driver) throws IOException, MalformedURLException {
		this.driver = driver;

		PageFactory.initElements(driver, this);
	}

	public void ClickonElement(WebElement Element) throws IOException {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Element.click();
		} catch (Exception e) {
			Log.info("Expected Element is not there");
			e.printStackTrace();
		}
	}

	public void SendDataOnElement(WebElement Element, String Data)
			throws IOException {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Element.sendKeys(Data);
		} catch (Exception e) {
			Log.info("Expected Element is not there");
			e.printStackTrace();
		}
	}

	public void ClearTheElement(WebElement Element) throws IOException {
		try {
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			Element.clear();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void clickByJavaExecuter(WebElement element) {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", element);
	}

	public void keyEnter(WebElement element) {
		WebElement textbox = element;
		textbox.sendKeys(Keys.ENTER);
	}

}
