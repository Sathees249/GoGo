package com.gogo.basesetup;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;
import com.gogo.constant.Constants;
import com.gogo.generics.Generics;
import com.gogo.utilities.Log;
import com.gogo.utilities.Reporting;

public class BaseSetup {

	public static WebDriver driver;
	public static ExtentHtmlReporter htmlReporter;

	public static ExtentReports extent;
	public static ExtentTest logger;
	public static String reportName = "Nil";

	public void SetClassName() {

	}

	@Parameters("myName")
	@BeforeSuite
	public void startTest(@Optional("NA") String myName) {

		/*SetClassName();
		if (!(myName.equals("NA"))) {
			System.out.println("name----->" + myName);
			reportName = myName;
		}*/
		htmlReporter = new ExtentHtmlReporter(Reporting.reportPath());
		extent = new ExtentReports();

		extent.attachReporter(htmlReporter);
		extent.setSystemInfo("Host Name", "Amazon Web Automation ");
		extent.setSystemInfo("Environment", "Test");
		htmlReporter.config().setDocumentTitle("AutomationReport_App Portal");
		htmlReporter.config().setReportName("GoGo Automation");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.STANDARD);

	}

	public void configWeb() throws IOException, InterruptedException {

		// HomePage homepage=new HomePage(driver);
		Constants con = new Constants();
		Generics gen = new Generics();
		String Firefox = "FireFox";
		String Chrome = "Chrome";

		String browser = gen.propertyFile("Browser");
		String URL = gen.propertyFile("url");

		if (Firefox.contentEquals(browser)) {
			System.getProperty("webdriver.gecko.driver", con.fireFoxDriverExe);
			driver = new FirefoxDriver();
			Log.info("FireFox browser has been initiated");
			driver.manage().window().maximize();
			Log.info("FireFox browser has been maximized");
			driver.manage().deleteAllCookies();
			driver.get(URL);
			Log.info("URL has been given in the browser as"+URL);
		}

		if (Chrome.contentEquals(browser)) {
			System.setProperty("webdriver.chrome.driver", con.chromeDriverExe);
			driver = new ChromeDriver();
			Log.info("Chrome browser has been initiated");
			driver.manage().window().maximize();
			Log.info("Chrome browser has been maximized");
			driver.manage().deleteAllCookies();
			driver.get(URL);
			Log.info("URL has been given in the browser as"+URL);
		}
	}

	@AfterMethod
	public void getResult(ITestResult result) throws IOException {

		if (result.getStatus() == ITestResult.FAILURE) {
			logger.fail(MarkupHelper.createLabel(result.getName()
					+ " - Test Case Failed", ExtentColor.RED));
			String screenShotPath = Reporting.capture(driver);
			logger.log(Status.FAIL,
					MarkupHelper.createLabel(result.getName()
							+ " Test case FAILED due to below issues:",
							ExtentColor.RED));
			logger.fail(result.getThrowable());
			logger.fail("Snapshot below: "
					+ logger.addScreenCaptureFromPath(screenShotPath));
			logger.fail(result.getThrowable());
		} else if (result.getStatus() == ITestResult.SKIP) {
			logger.skip(MarkupHelper.createLabel(result.getName()
					+ " - Test Case Skipped", ExtentColor.YELLOW));
			logger.skip(result.getThrowable());
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			logger.pass(MarkupHelper.createLabel(result.getName()
					+ " - Test Case Passed", ExtentColor.GREEN));
		}
	}

	@AfterSuite
	public void endReport() {
		extent.flush();
		
	}

}
