package com.gogo.testscenario;

import java.io.IOException;

import org.testng.annotations.Test;

import com.gogo.basesetup.BaseSetup;
import com.gogo.objects.AmazonSearchPage;

public class AmazonProductDetails extends BaseSetup {
	
	BaseSetup initialize;
	public AmazonProductDetails() throws IOException 
	{
		
	}
	/*public void SetClassName() {
		String[] args= getClassName().split("\\.");
		BaseSetup.reportName = args[2];
	}*/
	
	@Test
	public void toGetProductDetails() throws IOException, InterruptedException{
		String TestCaseName = getClassName();	
		logger = extent.createTest(TestCaseName);
        initialize = new BaseSetup();
        initialize.configWeb();
        AmazonSearchPage asp = new AmazonSearchPage(driver);
        asp.toSearchSelectedBook();
        asp.toGetSearchedBookDetails();
	}
	
	public String getClassName()
	{
		String TestCaseName = Thread.currentThread().getStackTrace()[1].getClassName();
		return TestCaseName;
	}
	

}
