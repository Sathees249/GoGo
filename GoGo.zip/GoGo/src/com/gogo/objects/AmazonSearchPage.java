package com.gogo.objects;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

//import demoAut.utilities.ExcelLib;
import com.gogo.basesetup.BaseSetup;
import com.gogo.constant.Constants;
import com.gogo.generics.Action;
import com.gogo.generics.Generics;
import com.gogo.utilities.Utils;
import com.gogo.utilities.Log;

//import abg.utilities.Screenshot;

public class AmazonSearchPage extends BaseSetup {
	WebDriver driver;


	// This is from Generic repository
	Constants con = new Constants();
	Utils Util;
	Action act;
	Generics gen;

	public AmazonSearchPage(WebDriver driver) throws IOException,
			MalformedURLException {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(xpath = "//*[@class='nav-search-facade']")
	public WebElement amazonListDropDown;

	@FindBy(id = "searchDropdownBox")
	public WebElement amazondropDown; // Books

	@FindBy(id = "twotabsearchtextbox")
	public WebElement searchField;

	@FindBy(className = "nav-search-dropdown searchSelect")
	public WebElement dropDownOpt;

	@FindBy(xpath = "//*[@value='Go']")
	public WebElement searchIcon;

	@FindBy(xpath = "//*[@class='aok-align-center']")
	public WebElement clickOnFirstBook;

	@FindBy(id = "ebooksProductTitle")
	public WebElement bookName;

	@FindBy(xpath = "//span[@class='a-size-medium a-color-base a-text-normal']")
	public WebElement meterialFirstName;

	/* Book Details */

	@FindBy(xpath = "//a[contains(text(),'Paperback')]")
	public WebElement paperBack;

	@FindBy(xpath = "//a[contains(text(),'Paperback')]//following::span[@class='a-price-whole']")
	public WebElement paperBackDollarVal;

	@FindBy(xpath = "//a[contains(text(),'Kindle')]")
	public WebElement kindle;

	@FindBy(xpath = "//a[contains(text(),'Kindle')]//following::span[@class='a-price-whole']")
	public WebElement kindleDollarVal;

	@FindBy(xpath = "//a[contains(text(),'Audible Audiobook')]")
	public WebElement AudiableAudioBook;

	@FindBy(xpath = "//a[contains(text(),'Audible Audiobook')]//following::span[@class='a-price-whole']")
	public WebElement AudiableAudioBookDollarVal;

	/* To Search with input data , which given by use */
	public void toSearchSelectedBook() throws MalformedURLException,
			IOException, InterruptedException {
		gen = new Generics();
		act = new Action(driver);
		String dropdownValue = gen.propertyFile("dropDownVal");
		System.out.println(dropdownValue);
		Log.info("Searching input value is:" + dropdownValue);
		act.SendDataOnElement(searchField, dropdownValue);
		Log.info("Entered with segment input value");
		act.ClickonElement(searchIcon);
		Log.info("Clicked on search Icon button");
		String bookName = gen.propertyFile("BookName");
		Log.info("Searching input book name is:" + bookName);
		act.SendDataOnElement(searchField, bookName);
		act.ClickonElement(searchIcon);
		Log.info("Clicked on search Icon button");
		String meterialName = meterialFirstName.getText();
		Log.info("The meterial Name is---->" + meterialName);

	}
	/* To get paperBack, Kindle, Audiable Edition details*/
	public void toGetSearchedBookDetails() throws InterruptedException {
		if (paperBack.isDisplayed()) {
			Log.info("Paper back edition is available");
			String paperBackVal = paperBackDollarVal.getText();
			Log.info("Paperbook" + " edition dollar value is:" + "$"
					+ paperBackVal);
		}
		if (kindle.isDisplayed()) {
			Log.info("Kindle edition is available");
			String kindleVal = kindleDollarVal.getText();
			Log.info("Kindle edition dollar value is:" + "$" + kindleVal);
		}
		if (AudiableAudioBook.isDisplayed()) {
			Log.info("AudiableAudioBook edition is available");
			String audibleAudioBookVal = AudiableAudioBookDollarVal.getText();
			Log.info("Audible audio edition dollar value is:" + "$"
					+ audibleAudioBookVal);
		}
	}

}
