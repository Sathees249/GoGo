package com.gogo.utilities;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import com.gogo.basesetup.BaseSetup;




public class Reporting 
{	
	static Date date = new Date();	
	String timestamp=new SimpleDateFormat("dd_MM_yyyy_hh_mm").format(date);	
	String currentdate = new SimpleDateFormat("dd_MM_yyyy").format(date);	
	static String fulltimestamp=new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss").format(date);	
	String minsstamp=new SimpleDateFormat("hh_mm").format(date);	
	
	public WebDriver driver;		
	
	public Reporting(WebDriver driver)
	{
		this.driver = driver;		
	}
		
	public static String rptpath;
	public static String ReportPath;
	public static String Path;
	public static String SSPath;
	
		
	public static String reportPath()
    {
		createReportFolder();
    	Date date=new Date();
    	SimpleDateFormat sdf=new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss a");
    	String Path="./reports/"+"Amazon Product Details"+sdf.format(date)+".html";
    	return Path;
    	//BaseSetup.reportName
    }
	
	public static void createReportFolder() 
	{	
		
		rptpath = "./Reports/";
		File files = new File(rptpath);
        if (!files.exists()) {
            if (files.mkdirs()) {
                //Logger.info("Multiple directories are created!");
            } else {
                //Logger.info("Failed to create multiple directories!");
            }
        } 
	}
		
	public static String capture(WebDriver driver) throws IOException {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		String destination = System.getProperty("user.dir") + "/FailedTestsScreenshots/" + dateName + ".png";
		TakesScreenshot ts = (TakesScreenshot) driver;
		try {
			
			File source = ts.getScreenshotAs(OutputType.FILE);
			File finalDestination = new File(destination);
			FileUtils.copyFile(source, finalDestination);
		} catch (Exception e) {
			e.getStackTrace();
			Log.info("Unable to take screenshot.");
		}
		//return destination;
		String base64Screenshot = "data:image/png;base64,"+ (ts.getScreenshotAs(OutputType.BASE64));
		return base64Screenshot;
	}
	
}