package com.gogo.utilities;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.testng.annotations.Test;
import org.openqa.selenium.TakesScreenshot;

public class Screenshot {

	public String CanonicalPath() throws Throwable {
		File file = new File(".");
		return file.getCanonicalPath();
	}

	public String date() {
		Date a = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("dd-MMM-yy");
		String dateValue = ft.format(a);
		return dateValue;
	}

	public String time() {
		Date a = new Date();
		SimpleDateFormat ft = new SimpleDateFormat("hh.mm.ss");
		String dateValue = ft.format(a);
		return dateValue;
	}

}
