package com.gogo.utilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.mail.Flags;
import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Store;
import javax.mail.search.FlagTerm;
import javax.mail.search.SubjectTerm;

import org.apache.commons.io.FileUtils;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.gogo.generics.Generics;

//import abg.utilities.VariableValues;
import bsh.util.Util;

public class Utils 
{
	static WebDriver driver;
	public static Dimension size;
	//This is for Excel sheet inputs from Utilities repository
	//ExcelLib excel = new ExcelLib();
	//This is from Generic repository
	Generics gen = new Generics();
	 Actions actions;
	Utils Util;

	public Utils(WebDriver driver) throws IOException ,MalformedURLException
	{
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	

	public  void scrollToTop() throws InterruptedException
	
	{
		Thread.sleep(2000);
		((JavascriptExecutor) driver).executeScript("scroll(0,250);");

	}

	public  void scrollToTopWithElement(WebElement val) throws InterruptedException
	
	{
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
                ,val);

	}
	
	public void scrollToTargetElement(WebElement val)
	{
		
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", val);

	}
	
	public void appScroll(WebElement frame, WebElement target)
	{
		//WebElement sccc = driver.findElement(By.xpath("//div[@id='container-scrollTop']"));
		Actions drag = new Actions(driver);
		
//		drag.dragAndDropBy(sccc, xOffset, yOffset)
		
		//WebElement api = driver.findElement(By.xpath("//div[@id = 'block-tempest-content']//a[@href = '/docs']"));
		((JavascriptExecutor) driver).executeScript(
			    "arguments[0].scrollTop=arguments[1].offsetTop",
			    frame,
			    target); 
	}
	
	public void windowScroll()
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,3000)", "");
	}
	
	public void windowScrollToCenter()
	{
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,600)", "");
	}
	
	public void scrollwithExecutor(WebElement val)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].scrollTop = arguments[0].scrollHeight", val);
	}
	
	public void actionScroll(WebElement val)
	{
		actions = new Actions(driver);
		actions.moveToElement(val);
		actions.perform();
	}
	
	public String screenShotCapture() throws IOException {
		String dateName = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());
		String destination = System.getProperty("user.dir") + "/TestsScreenshots/" + dateName + ".png";
		TakesScreenshot ts = (TakesScreenshot) driver;
		try {
			
			File source = ts.getScreenshotAs(OutputType.FILE);
			File finalDestination = new File(destination);
			FileUtils.copyFile(source, finalDestination);
		} catch (Exception e) {
			e.getStackTrace();
			Log.info("Unable to take screenshot.");
		}
		//return destination;
		String base64Screenshot = "data:image/png;base64,"+ (ts.getScreenshotAs(OutputType.BASE64));
		return base64Screenshot;
	}
	
	public void takepassedScreenshot() throws IOException{

		TakesScreenshot scrShot =((TakesScreenshot)driver);
		String SrcFile=scrShot.getScreenshotAs(OutputType.BASE64);
		String Screenshot="data:image/jpg;base64, " + SrcFile;
	}
	
	public void scrollToLinkVal(WebElement scrolBox, WebElement element)
    {
    	//WebElement sccc = driver.findElement(By.xpath("//div[@id='container-scrollTop']"));
		Actions drag = new Actions(driver);
		
//		drag.dragAndDropBy(sccc, xOffset, yOffset)
		
		//WebElement api = driver.findElement(By.xpath("//div[@id = 'block-tempest-content']//a[@href = '/docs']"));
		((JavascriptExecutor) driver).executeScript(
			    "arguments[0].scrollTop=arguments[1].offsetTop",
			    scrolBox,
			    element); 
    }


	

	
	
}
